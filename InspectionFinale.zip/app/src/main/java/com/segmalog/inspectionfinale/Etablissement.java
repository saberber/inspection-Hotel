package com.segmalog.inspectionfinale;

import java.util.Date;

/**
 * Created by Segma on 2/16/2015.
 */
public class Etablissement {

    private String title;
    private String dateeta;
    private int etat;



    public Etablissement(String title, String dateeta, int etat) {
        super();
        this.title = title;
        this.dateeta = dateeta;
        this.etat = etat;

    }

    public String getTitle() {
        return title;
    }



    public int getEtat() {
        return etat;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDateeta() {
        return dateeta;
    }

    public void setDateeta(String dateeta) {
        this.dateeta = dateeta;
    }

    public void setEtat(int etat) {
        this.etat = etat;
    }
}
