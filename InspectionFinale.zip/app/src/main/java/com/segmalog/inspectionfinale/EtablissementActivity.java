package com.segmalog.inspectionfinale;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.RatingBar.OnRatingBarChangeListener;

public class EtablissementActivity extends ActionBarActivity implements OnRatingBarChangeListener{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity3);
        // Get a reference to the AutoCompleteTextView in the layout
        final AutoCompleteTextView textView = (AutoCompleteTextView) findViewById(R.id.autoCompleteTextView);
        final TextView text3 = (TextView) findViewById(R.id.editText3);

        final TextView text7 = (TextView) findViewById(R.id.editText7);
        final TextView text8 = (TextView) findViewById(R.id.editText8);
        final TextView text9 = (TextView) findViewById(R.id.editText9);
        final TextView text10 = (TextView) findViewById(R.id.editText10);
        final RatingBar rtb= (RatingBar) findViewById(R.id.ratingBar);
        final RatingBar rtb2= (RatingBar) findViewById(R.id.ratingBar2);

        // Get the string array
        String[] countries = getResources().getStringArray(R.array.countries_array);
        // Create the adapter and set it to the AutoCompleteTextView
        ArrayAdapter<String> adapter =
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, countries);
        textView.setThreshold(1);
        textView.setAdapter(adapter);


        /////
        textView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick (AdapterView<?> parent, View view, int position, long id) {
                String txt = textView.getText().toString();
               if(txt.equals("11111")) {
                    text3.setText("Dar djerba");
                    rtb.setRating(3.0f);
                   rtb2.setRating(4.0f);
                    text7.setText("djerba zone touristique");
                    text8.setText("foulen ben foulen");
                    text9.setText("foulen ben foulen");
                    text10.setText("foulen ben foulen");
                }else  if(txt.equals("22222")) {
                    text3.setText("Green palme");
                    rtb.setRating(2.0f);
                   rtb2.setRating(5.0f);
                    text7.setText("djerba houmt souk");
                    text8.setText("Moez moez");
                    text9.setText("Moez moez");
                    text10.setText("Moez moez");
                }else{
                    text3.setText("");
                    rtb.setNumStars(0);
                    text7.setText("");
                    text8.setText("");
                    text9.setText("");
                    text10.setText("");
                }
            }
        });



        Drawable d=getResources().getDrawable(R.drawable.actionbar);
        getSupportActionBar().setBackgroundDrawable(d);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        /////
        Button btn  = (Button) findViewById(R.id.button11);
        btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EtablissementActivity.this, InspectionActivity.class);
                startActivity(intent);
            }
        });

    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main_activity3, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {

    }
}
