package com.segmalog.inspectionfinale;

/**
 * Created by Segma on 2/14/2015.
 */
public class Inspection {


    private String title;
    private int probID;
    private int iconID;

    public Inspection(String title, int iconID) {
        this.title = title;
        this.iconID = iconID;
    }

    public Inspection(String title, int iconID, int probID) {
        super();
        this.title = title;
        this.probID = probID;
        this.iconID = iconID;

    }

    public void setIconID(int iconID) {
        this.iconID = iconID;
    }

    public void setProbID(int probID) {
        this.probID = probID;
    }

    public String getTitle() {
        return title;
    }

    public int getProbID() {
        return probID;
    }

    public int getIconID() {
        return iconID;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
