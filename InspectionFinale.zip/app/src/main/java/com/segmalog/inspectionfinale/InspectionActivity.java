package com.segmalog.inspectionfinale;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;


public class InspectionActivity extends ActionBarActivity {
    private List<Inspection> inspect = new ArrayList<Inspection>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        ///
        populateInspecList();
        populateListView();

        ///
        Intent intent = getIntent();
        Drawable d=getResources().getDrawable(R.drawable.actionbar);
        getSupportActionBar().setBackgroundDrawable(d);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void populateInspecList() {
        inspect.add(new Inspection("Etape 1", R.drawable.green, R.drawable.yellow));
        inspect.add(new Inspection("Etape 2", R.drawable.green, R.drawable.yellow));
        inspect.add(new Inspection("Etape 3", R.drawable.red));
        inspect.add(new Inspection("Etape 4", R.drawable.red,R.drawable.redprob));
    }

    private void populateListView() {
        final ArrayAdapter<Inspection> adapter = new MyListAdapter();
        final ListView list = (ListView) findViewById(R.id.listView);
        list.setAdapter(adapter);


        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int pos, long arg3) {
                Intent i;
           if(pos == 0) {

                i = new Intent(InspectionActivity.this, List1Activity.class);
               startActivity(i);
           }else if(pos == 1){
                    i = new Intent(InspectionActivity.this, List2Activity.class);
                    startActivity(i);
           }else if(pos == 2){
               i = new Intent(InspectionActivity.this, List3Activity.class);
               startActivity(i);
           }else if(pos == 3){
               i = new Intent(InspectionActivity.this, List4Activity.class);
               startActivity(i);
           }





         }
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_list, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public class MyListAdapter extends ArrayAdapter<Inspection> {
        public MyListAdapter() {
            super(InspectionActivity.this, R.layout.item_view, inspect);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Make sure we have a view to work with (may have been given null)
            View itemView = convertView;
            if (itemView == null) {
                itemView = getLayoutInflater().inflate(R.layout.item_view, parent, false);
            }

            // Find the car to work with.
            Inspection currentInspect = inspect.get(position);

            // Fill the view
            ImageView imageView = (ImageView)itemView.findViewById(R.id.item_icon);
            imageView.setImageResource(currentInspect.getIconID());

            // Make:
            TextView titleText = (TextView) itemView.findViewById(R.id.item_txtMake);
            titleText.setText(currentInspect.getTitle());

            // Fill the view
            ImageView imageProb = (ImageView)itemView.findViewById(R.id.item_prob);
            imageProb.setImageResource(currentInspect.getProbID());

            return itemView;
        }
    }
}
