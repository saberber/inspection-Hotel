package com.segmalog.inspectionfinale;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;


public class ListSauvgardeActivity extends ActionBarActivity {
    private List<Etablissement> inspect = new ArrayList<Etablissement>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_sauvgarde);
        ///
        populateInspecList();
        populateListView();


        Intent intent = getIntent();
        Drawable d=getResources().getDrawable(R.drawable.actionbar);
        getSupportActionBar().setBackgroundDrawable(d);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    private void populateListView() {


        final ArrayAdapter<Etablissement> adapter = new MyListAdapter();
        final ListView list = (ListView) findViewById(R.id.listView7);
        list.setAdapter(adapter);
    }

    private void populateInspecList() {

        inspect.add(new Etablissement("REf-001 : Hotel Dar djerba","12/12/2012 - Etat : Terminé", R.drawable.ic_action_tick));
        inspect.add(new Etablissement("REf-002 : Hotel Green Palme","12/12/2012 - Etat : En cours", R.drawable.ic_action_reload));

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_list_sauvgarde, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noEtablissement SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public class MyListAdapter extends ArrayAdapter<Etablissement> {
        public MyListAdapter() {
            super(ListSauvgardeActivity.this, R.layout.item_etablissement, inspect);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Make sure we have a view to work with (may have been given null)
            View itemView = convertView;
            if (itemView == null) {
                itemView = getLayoutInflater().inflate(R.layout.item_etablissement, parent, false);
            }

            // Find the car to work with.
            Etablissement currentInspect = inspect.get(position);

            // Fill the view
            ImageView imageView = (ImageView)itemView.findViewById(R.id.item_prob);
            imageView.setImageResource(currentInspect.getEtat());

            // Make:
            TextView titleText = (TextView) itemView.findViewById(R.id.item_txtMake);
            titleText.setText(currentInspect.getTitle());

            // Make:
            TextView dateetat = (TextView) itemView.findViewById(R.id.textView24);
            dateetat.setText(currentInspect.getDateeta());

            return itemView;
        }
    }
}
