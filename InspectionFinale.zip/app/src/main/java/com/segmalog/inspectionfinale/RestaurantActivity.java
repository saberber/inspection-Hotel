package com.segmalog.inspectionfinale;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;




public class RestaurantActivity extends ActionBarActivity {
    private List<Inspection> inspect = new ArrayList<Inspection>();
    public String value = "0";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant);
        ///
        Bundle extras = getIntent().getExtras();

        if (extras != null) {
            value = extras.getString("success");
        }
        populateInspecList();
        populateListView();

        ///
        Intent intent = getIntent();
        Drawable d=getResources().getDrawable(R.drawable.actionbar);
        getSupportActionBar().setBackgroundDrawable(d);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    private void populateListView() {


        final ArrayAdapter<Inspection> adapter = new MyListAdapter();
        final ListView list = (ListView) findViewById(R.id.listView6);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int pos, long arg3) {
                Intent i;
                if(pos == 0) {
                    if(value.equals("1")){

                        Toast.makeText(getApplicationContext(), "Vous avez déja valider cette tache",
                                Toast.LENGTH_LONG).show();
                    }else {
                        i = new Intent(RestaurantActivity.this, RestProcessActivity.class);
                        startActivity(i);
                    }
                }
            }
        });
    }

    private void populateInspecList() {


        if(value.equals("1")){
            inspect.add(new Inspection("Portes en bonne état", R.drawable.green));
        }else{
            inspect.add(new Inspection("Portes en bonne état", R.drawable.red));

        }

        inspect.add(new Inspection("Présence d'un judas", R.drawable.red));

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_restaurant, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public class MyListAdapter extends ArrayAdapter<Inspection> {
        public MyListAdapter() {
            super(RestaurantActivity.this, R.layout.item_view, inspect);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Make sure we have a view to work with (may have been given null)
            View itemView = convertView;
            if (itemView == null) {
                itemView = getLayoutInflater().inflate(R.layout.item_view, parent, false);
            }

            // Find the car to work with.
            Inspection currentInspect = inspect.get(position);

            // Fill the view
            ImageView imageView = (ImageView)itemView.findViewById(R.id.item_icon);
            imageView.setImageResource(currentInspect.getIconID());

            // Make:
            TextView titleText = (TextView) itemView.findViewById(R.id.item_txtMake);
            titleText.setText(currentInspect.getTitle());

            // Fill the view
            ImageView imageProb = (ImageView)itemView.findViewById(R.id.item_prob);
            imageProb.setImageResource(currentInspect.getProbID());

            return itemView;
        }
    }



}
